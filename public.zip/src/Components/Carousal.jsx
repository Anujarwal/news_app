import React from 'react'
import image2 from "../assets/templates-2.mp4"
import image1 from "../assets/Sports Intro - After Effects Templates Motion Array.mp4"
import image3 from "../assets/Templates -3.mp4"

const Carousal = () => {

  const customStyle = {
    
  }

  return (
<div id="carouselExample" className="carousel slide">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <video src={image2} autoPlay muted loop className='d-block w-100' style={customStyle}></video>
    </div>
    <div className="carousel-item">
    <video src={image1} autoPlay muted loop className='d-block w-100' style={customStyle}></video>
    </div>
    <div className="carousel-item">
    <video src={image3} autoPlay muted loop className='d-block w-100' style={customStyle}></video>
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>  )
}

export default Carousal