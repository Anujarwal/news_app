import React from "react";

const WeatherCard = () => {
  return (
    <div className="col-md-4 col-sm-12">
      <div className="card p-5">
        <h4 className="text-secondary">Today Weather</h4>
        <h1>26°</h1>
        <h2>Indore</h2>
        <img src="//cdn.weatherapi.com/weather/64x64/night/143.png" alt="" style={{width : "50px" }} />
        <h1>Cloud</h1>
      </div>
    </div>
  );
};

export default WeatherCard;
