import React from "react";

const NewsCard = ({news}) => {

    const {title , description , url , urlToImage , author , image} = news


  return (
    <div className="col-12">
     <div className="card mb-3">
  <div className="row g-0">
    <div className="col-md-4">
      <img src={image} className="img-fluid rounded-start" alt="..."/>
    </div>
    <div className="col-md-8">
      <div className="card-body">
        <h5 className="card-title">{title}</h5>
        <p className="card-text">{description}</p>
        <p className="card-text"><small className="text-body-secondary">{author}</small></p>
        <a href={url} target="_blank" rel="noreferrer" className="btn btn-primary btn-sm">Read More</a>
      </div>
    </div>
  </div>
</div>
    </div>
  );
};

export default NewsCard;
