// let key = 'ccd1627506c34f959c9106137fc1be2d'
// let key = '202c188d1fe74f3285a0207f7aa32c6f'

export const fetchNews = async (topic) => {
  // const response = await fetch(
  //   `https://newsapi.org/v2/everything?q=${topic}&from=2024-01-10&sortBy=publishedAt&apiKey=ccd1627506c34f959c9106137fc1be2d`
  // );
  const response = await fetch(
    `https://fakestoreapi.com/products`
  );
  const data = await response.json();
  return data;
};
