import React, { useContext, useEffect } from "react";
import Carousal from "../Components/Carousal";
import WeatherCard from "../Components/WeatherCard";
import NewsCard from "../Components/NewsCard";
import NewsContext from "../Context/News/NewsContext";
import { fetchNews } from "../Context/News/NewsAction";

const Home = () => {
  const { newsAll, newsDispatch } = useContext(NewsContext);

  const getNews = async (topic) => {
    const data = await fetchNews();

    newsDispatch({
      type: "GET_NEWS",
      payload: data,
    });
  };

  useEffect(() => {
    getNews();
  }, []);


  // console.log(newsAll)

  return (
    <>
      <Carousal />

      <div className="container-fluid p-5">
        <h3 className="text-center MY-3">Top News</h3>

        <section>
          <div className="row g-3">
            <WeatherCard />
            <div className="col-md-8 col-sm-12">
              {newsAll && newsAll.map((news, index) => (
                <NewsCard news={news} key={news.index} />
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
